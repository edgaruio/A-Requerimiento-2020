# -*- coding: utf-8 -*-
import pkg_resources


__version__ = "0.1.2"

pkg_resources.declare_namespace(__name__)
